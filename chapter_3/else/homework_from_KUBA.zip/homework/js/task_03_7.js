document.addEventListener("mousemove",(e) => {
    console.log('X= ' + e.clientX, 'Y= ' + e.clientY )
})