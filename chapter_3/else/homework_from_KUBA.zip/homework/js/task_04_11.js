$(document).on('mousemove', (e) => {
    console.log('X= ' + e.offsetX, 'Y= ' + e.offsetY)
})